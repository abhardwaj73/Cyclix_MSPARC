close all
clear
clc

% Convergence of energy, force, stress with eta_points
% System : (12,8) CNT tube, 10 Bohr vacuum, and no external twist
% mesh-size = 0.2 Bohr, C-C bond length = 2.67 Bohr, LDA psp

N_dtp = 11;
n_atm = 2;
kpt = [1 20 40 60 80 100 120 140 180 200];
kpt_ref = 400;
W_cnt= [-6.2029382932E+00
        -5.5966504973E+00
        -5.5968959890E+00
        -5.5969677529E+00
        -5.5969171677E+00
        -5.5969337522E+00
        -5.5969491882E+00
        -5.5969311821E+00
        %-5.5969368507E+00
        -5.5969375328E+00
        -5.5969357627E+00 
        %-5.5969370255E+00
        %-5.5969369204E+00
        -5.5969367335E+00]; % in Ha/atom

F_cnt = [-1.8741016918E-02   2.5425429950E-03  -6.0931499973E-03
         -5.1975711992E-03  -1.8184355624E-02   6.0931499973E-03
          4.0341194906E-02   3.3763618425E-02  -8.5941790234E-02
          4.7117484947E-02   2.3394440065E-02   8.5941790234E-02
          4.0189367533E-02   3.8167308309E-02  -9.6598730738E-02
          5.1089292137E-02   2.1485659424E-02   9.6598730738E-02
          3.9891358478E-02   3.8095687860E-02  -9.5999758294E-02
          5.0904032683E-02   2.1241949177E-02   9.5999758294E-02
          3.9792144002E-02   3.8375985859E-02  -9.6619107290E-02
          5.1120841093E-02   2.1038522872E-02   9.6619107290E-02
          3.9961596013E-02   3.8128478631E-02  -9.6246912732E-02
          5.0962304606E-02   2.1293069704E-02   9.6246912732E-02
          3.9818148978E-02   3.8334958345E-02  -9.6591621608E-02
          5.1093727839E-02   2.1078780495E-02   9.6591621608E-02
          3.9969425291E-02   3.7801756596E-02  -9.5456140184E-02
          5.0666203123E-02   2.1431491876E-02   9.5456140184E-02
         % 3.9903993132E-02   3.8196945745E-02  -9.6341488507E-02
         % 5.1001911501E-02   2.1213027609E-02   9.6341488507E-02
          3.9897225818E-02   3.8073436483E-02  -9.6040341780E-02
          5.0886067524E-02   2.1256412990E-02   9.6040341780E-02
          3.9869007756E-02   3.8246605638E-02  -9.6433509701E-02
          5.1033260082E-02   2.1160882615E-02   9.6433509701E-02
         % 3.9911906725E-02   3.8067531363E-02  -9.6040559685E-02
         % 5.0886465190E-02   2.1272018559E-02   9.6040559685E-02
         % 3.9902889345E-02   3.8119808030E-02  -9.6161014729E-02
         % 5.0930750976E-02   2.1242821599E-02   9.6161014729E-02
          3.9888177249E-02   3.8168632942E-02  -9.6263027556E-02
          5.0969576902E-02   2.1209788195E-02   9.6263027556E-02
]; % in Ha/Bohr

T_cnt = [ 2.7689336542E-01
         -1.8079192360E+00
         -1.9034317218E+00 
         -1.8943506268E+00 
         -1.8967058123E+00
         -1.8993858517E+00 
         -1.8978618589E+00 
         -1.8889480407E+00 
         %-1.8970232592E+00 
         -1.8945953397E+00 
         -1.8973537588E+00
         %-1.8942618390E+00
         %-1.8955324902E+00
         -1.8961609735E+00]; % in Ha/Bohr

% Compute error
%--------------

dW_cnt = abs(W_cnt(1:end-1) - W_cnt(end));
dF_cnt = zeros(N_dtp-1,1);
F_ref = F_cnt(n_atm*(N_dtp-1)+1:end,:);
for i = 1:N_dtp-1
    dF_cnt(i) = 1e-16;
    for j = 1:n_atm
        err = norm(F_cnt(n_atm*(i-1)+j,:) - F_ref(j,:),inf);
        if err > dF_cnt(i)
            dF_cnt(i) = err;
        end
    end
end
dT_cnt = abs((T_cnt(1:end-1) - T_cnt(end))*100/T_cnt(end));

% Error plot
%------------

figure1 = figure;
box on

hold on
plot(kpt,dW_cnt,'r','Marker','o','MarkerSize',8,'LineWidth',1,'LineStyle','-')
plot(kpt,dF_cnt,'color',[0 0.75 0],'Marker','*','MarkerSize',8,'LineWidth',1,'LineStyle','-.')
%plot(kpt,dT_cnt,'b','Marker','sq','MarkerSize',10,'LineWidth',1,'LineStyle','-')

set(gca,'TickLabelInterpreter','LaTex');
set(gca,'yscale','log','XTick',[0 40 80 120 160 200],'YTick',[1e-6 1e-5 1e-4 1e-3 1e-2 1e-1 1e0],'TickLength',[0.018 0.025],'FontName','Times New Roman','FontSize',16);
%set(gca,'XTickLabel',num2str(get(gca,'XTick')','%.2f'))
set(gca,'YTickLabel',{'$10^{-6}$', '$10^{-5}$','$10^{-4}$', '$10^{-3}$', '$10^{-2}$', '$10^{-1}$', '$10^{0}$'});
xlim([0 202]);
ylim([5e-7 1.5]);

xlabel('$\# \eta$','FontSize',16,'FontName','Times New Roman','Interpreter','LaTex');
ylabel('Error','FontSize',16,'FontName','Times New Roman','Interpreter','LaTex');


yyaxis right
plot(kpt,dT_cnt,'b','Marker','d','MarkerSize',8,'LineWidth',1,'LineStyle','--')

set(gca,'TickLabelInterpreter','LaTex');
set(gca,'yscale','log','YTick',[1e-2 1e-1 1e0 1e1 1e2],'TickLength',[0.018 0.025],'Ycolor',[0 0 0],'FontName','Times New Roman','FontSize',16);
%set(gca,'XTickLabel',num2str(get(gca,'XTick')','%.2f'))
set(gca,'YTickLabel',{'$10^{-2}$','$10^{-1}$', '$10^{0}$','$10^{1}$', '$10^{2}$'});
ylim([1e-2 120]);

ylabel('\% Error','FontSize',16,'FontName','Times New Roman','Interpreter','LaTex');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legend1 = legend('Energy (Ha/atom)','Force (Ha/Bohr)','Axial stress (\%)','Location','Northeast');
set(legend1,'fontsize',16,'FontName','Times New Roman','Interpreter','LaTex');


set(figure1,'Units','Inches');
pos = get(figure1,'Position');
set(figure1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[1.02*pos(3), 1.02*pos(4)])
saveas(gcf,'errorVskpt','epsc')
hold off
