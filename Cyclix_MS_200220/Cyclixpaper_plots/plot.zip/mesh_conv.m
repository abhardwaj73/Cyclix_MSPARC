close all
clear
clc

% Convergence of energy, force, stress with mesh size
% System : (12,8) CNT tube, 10 Bohr vacuum, and no external twist
% eta = 50, C-C bond length = 2.67 Bohr, LDA psp

N_dtp = 7;
n_atm = 2;
mesh = [0.30 0.25 0.22 0.175 0.15 0.125];
mesh_ref = 0.10;
W_cnt= [-5.5944026921E+00
        -5.5966987248E+00
        -5.5969281360E+00
        %-5.5969661340E+00
        %-5.5969084279E+00
        -5.5969842516E+00
        -5.5969768277E+00
        -5.5969629595E+00
        -5.5969638161E+00]; % in Ha/atom

F_cnt = [3.8108927051E-02   3.7367085644E-02  -9.4764918968E-02
         5.1261032545E-02   2.3863749567E-02   9.4764918968E-02
         3.9708081996E-02   3.7326642649E-02  -9.4605053553E-02
         5.0210166033E-02   2.1639502578E-02   9.4605053553E-02
         4.0153653163E-02   3.7336585015E-02  -9.4624064872E-02
         5.0286747571E-02   2.1740893899E-02   9.4624064872E-02
         %4.0197201004E-02   3.7336086354E-02  -9.4615751574E-02
         %5.0337811543E-02   2.1794721935E-02   9.4615751574E-02
         %4.0202666971E-02   3.7333365711E-02  -9.4608544802E-02
         %5.0337584745E-02   2.1818663809E-02   9.4608544802E-02
         4.0196919380E-02   3.7334532490E-02  -9.4612884333E-02
         5.0334341938E-02   2.1809059037E-02   9.4612884333E-02
         4.0200938049E-02   3.7333639524E-02  -9.4610049814E-02
         5.0336807171E-02   2.1813090299E-02   9.4610049814E-02
         4.0200799511E-02   3.7332548284E-02  -9.4607429763E-02
         5.0336010610E-02   2.1816843518E-02   9.4607429763E-02
         4.0199893066E-02   3.7332153721E-02  -9.4606847897E-02
         5.0336458582E-02   2.1819030092E-02   9.4606847897E-02]; % in Ha/Bohr

T_cnt = [-4.1693998392E+00
         -1.6625094601E+00
         -1.8852785057E+00
         %-1.8765943123E+00
         %-1.8694227404E+00
         -1.8701005311E+00
         -1.8700846255E+00
         -1.8700173512E+00
         -1.8700364293E+00]; % in Ha/Bohr

% Compute error
%--------------

dW_cnt = abs(W_cnt(1:end-1) - W_cnt(end));
dF_cnt = zeros(N_dtp-1,1);
F_ref = F_cnt(n_atm*(N_dtp-1)+1:end,:);
for i = 1:N_dtp-1
    dF_cnt(i) = 1e-16;
    for j = 1:n_atm
        err = norm(F_cnt(n_atm*(i-1)+j,:) - F_ref(j,:),inf);
        if err > dF_cnt(i)
            dF_cnt(i) = err;
        end
    end
end
dT_cnt = abs((T_cnt(1:end-1) - T_cnt(end))*100/T_cnt(end));

% Error plot
%------------

figure1 = figure;
box on

hold on
plot(mesh,dW_cnt,'r','Marker','o','MarkerSize',8,'LineWidth',1,'LineStyle','-')
plot(mesh,dF_cnt,'color',[0 0.75 0],'Marker','*','MarkerSize',8,'LineWidth',1,'LineStyle','-.')
%plot(kpt,dT_cnt,'b','Marker','sq','MarkerSize',10,'LineWidth',1,'LineStyle','-')

set(gca,'TickLabelInterpreter','LaTex');
set(gca,'yscale','log','xdir','reverse','XTick',[0.10 0.15 0.20 0.25 0.30],'YTick',[1e-6 1e-5 1e-4 1e-3 1e-2],'TickLength',[0.018 0.025],'FontName','Times New Roman','FontSize',16);
%set(gca,'XTickLabel',num2str(get(gca,'XTick')','%.2f'))
set(gca,'YTickLabel',{'$10^{-6}$', '$10^{-5}$','$10^{-4}$', '$10^{-3}$', '$10^{-2}$'});
xlim([0.10 0.32]);
ylim([5e-7 1e-2]);

xlabel('mesh size (Bohr)','FontSize',16,'FontName','Times New Roman','Interpreter','LaTex');
ylabel('Error','FontSize',16,'FontName','Times New Roman','Interpreter','LaTex');


yyaxis right
plot(mesh,dT_cnt,'b','Marker','d','MarkerSize',8,'LineWidth',1,'LineStyle','--')

set(gca,'TickLabelInterpreter','LaTex');
set(gca,'yscale','log','YTick',[1e-3 1e-2 1e-1 1e0 1e1 1e2],'TickLength',[0.018 0.025],'Ycolor',[0 0 0],'FontName','Times New Roman','FontSize',16);
%set(gca,'XTickLabel',num2str(get(gca,'XTick')','%.2f'))
set(gca,'YTickLabel',{'$10^{-3}$','$10^{-2}$','$10^{-1}$', '$10^{0}$','$10^{1}$', '$10^{2}$'});
ylim([8e-4 130]);

ylabel('\% Error','FontSize',16,'FontName','Times New Roman','Interpreter','LaTex');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legend1 = legend('Energy (Ha/atom)','Force (Ha/Bohr)','Axial stress (\%)','Location','Northeast');
set(legend1,'fontsize',16,'FontName','Times New Roman','Interpreter','LaTex');


set(figure1,'Units','Inches');
pos = get(figure1,'Position');
set(figure1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[1.02*pos(3), 1.02*pos(4)])
saveas(gcf,'errorVsmesh','epsc')
hold off
